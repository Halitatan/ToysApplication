package com.example.toysapplication;

import java.util.ArrayList;
import java.util.List;

public class ToysApplication {
    public static void main(String[] args) {
        List<String> toysList = new ArrayList<>();
        toysList.add("Action Figure");
        toysList.add("Doll");
        toysList.add("Building Blocks");
        toysList.add("Puzzle");
        toysList.add("Board Game");
        toysList.add("Teddy Bear");
        toysList.add("Remote Control Car");
        toysList.add("Toy Kitchen Set");
        toysList.add("Robot Toy");
        toysList.add("Stuffed Animal");

        System.out.println("Oyuncak Listesi:");
        for (String toy : toysList) {
            System.out.println(toy);
        }
    }
}
